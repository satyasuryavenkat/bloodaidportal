<p><a href="dashboard.php">Dashboard</a> | <a href="logout.php">Logout</a></p>
<?php
require('db.php');
include("auth.php");

if(isset($_POST["Import"])){
    
    $filename=$_FILES["file"]["tmp_name"];    
     if($_FILES["file"]["size"] > 0)
     {
        $file = fopen($filename, "r");
          while (($getData = fgetcsv($file, 10000, ",")) !== FALSE)
           {
             $sql = "INSERT into bloo (`id`, `uname`, `blood`, `age`, `mobile`, `city`, `dd`) 
                   values ('$getData[0]','$getData[1]','$getData[2]','$getData[3]','$getData[4]','$getData[5]','$getData[6]')";
                   $result = mysqli_query($con, $sql);
        if(!isset($result))
        {
          echo "<script type=\"text/javascript\">
              alert(\"Invalid File:Please Upload CSV File.\");
              window.location = \"dashboard.php\"
              </script>";    
        }
        else {
            echo "<script type=\"text/javascript\">
            alert(\"CSV File has been successfully Uploaded.\");
            window.location = \"dashboard.php\"
          </script>";
        }
           }
      
           fclose($file);  
     }
  }   
   if(isset($_POST["Export"])){
     
      header('Content-Type: text/csv; charset=utf-8');  
      header('Content-Disposition: attachment; filename=data.csv');  
      $output = fopen("php://output", "w");  
      fputcsv($output, array('ID', 'Donor Name', 'Blood Group', 'Age', 'Mobile', 'City', 'Last Donated Months'));  
      $query = "SELECT * from bloo ORDER BY id DESC";  
      $result = mysqli_query($con, $query);  
      while($row = mysqli_fetch_assoc($result))  
      {  
           fputcsv($output, $row);  
      }  
      fclose($output);  }
 ?>