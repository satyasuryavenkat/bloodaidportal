<?php
require('db.php');
include("auth.php");

$status = "";
if(isset($_POST['new']) && $_POST['new']==1)
{
    $username =$_REQUEST['username'];
    $email=$_REQUEST['email'];
    $contactno =$_REQUEST['contactno'];
    $clgid =$_REQUEST['clgid'];
    $region=$_REQUEST['region'];
    $clg=$_REQUEST['clg'];
    $state=$_REQUEST['state'];
    $password=$_REQUEST['password'];
$ins_query="insert into admins (`username`,`email`,`contactno`,`clgid`,`region`,`clg`,`state`,`password`) values ('$username','$email','$contactno','$clgid','$region','$clg','$state','$password')";
mysqli_query($con,$ins_query) or die(mysql_error());
$status = "New Record Inserted Successfully.</br></br>";
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Insert New Record</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<div class="form">
<div>
    <p><a href="dashboard.php">Dashboard</a> | <a href="logout.php">Logout</a></p>
<h1>Create New Admin</h1>
<form name="form" method="post" action=""> 
<input type="hidden" name="new" value="1" />
<p><input type="text" name="username" placeholder="Enter Name" required  /></p>
<p><input type="text" name="email" placeholder="Enter Email Address" required  /></p>
<p><input type="text" name="contactno" placeholder="Enter Mobile number" required  /></p>
<p><input type="text" name="clgid" placeholder="Enter Collage id number" required  /></p>
<p><input type="text" name="region" placeholder="Enter region of admin" required  /></p>
<p><input type="text" name="clg" placeholder="Enter Collage name present studying" required  /></p>
<p><input type="text" name="state" placeholder="Enter state" required  /></p>
<p><input type="text" name="password" placeholder="Enter password" required  /></p>
<p><input name="submit" type="submit" value="insert" /></p>
</form>
<p style="color:#FF0000;"><?php echo $status; ?></p>
</div>
</div>
</body>
</html>
