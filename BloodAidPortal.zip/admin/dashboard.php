<?php
require('db.php');
include("auth.php"); //include auth.php file on all secure pages ?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Dashboard - Secured Page</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<div class="form">
<p>Welcome to Dashboard.</p>

<p><a href="index.php">Home</a><p>
<p><a href="insert.php">Insert New Donor Record</a></p>
<p><a href="view.php">View Donor Records</a><p>
<p><a href="view1.php">View requested Records</a><p>
<p><a href="insertintodonor.php">Fill Donor and Blood Requiested Person Details</a></p>
<p><a href="view2.php">View Donated Records</a><p>
<p><a href="bulkupload.html">To Bulk Upload the Data</a></p>
<p><a href="createadmin.php">Create Admin</a></p>

    <form method="POST" action="filter_search.php" class="bg-white rounded pb_form_v1" >
         <div class="form-group">
                
                  <select name="blood" class="form-control pb_height-50 reverse">
                    <option value="" selected>Blood Group You Required</option>
                    <option value="A+">A+</option>
                    <option value="A-">A-</option>
                    <option value="B+">B+</option>
                    <option value="B-">B-</option>
                    <option value="AB+">AB+</option>
                    <option value="AB-">AB-</option>
                    <option value="O+">O+</option>
                    <option value="O-">O-</option>
                    
                  </select>
            <input type="submit" name="submit" class="btn btn-primary btn-lg btn-block pb_btn-pill  btn-shadow-blue" value="Search">
          </div>
        </form>
<p><a href="logout.php">Logout</a></p>


</div>
</body>
</html>
