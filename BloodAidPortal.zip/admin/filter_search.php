<?php
require('db.php');
include("auth.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Update Record</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<div class="form">
<center><p><a href="index.php">Home</a> | <a href="insert.php">Insert New Record</a> | <a href="logout.php">Logout</a></p></center>
<table width="100%" border="1" style="border-collapse:collapse;">
<thead>
<tr><th><strong>S.No</strong></th><th><strong>Name</strong></th><th><strong>Blood Group</strong></th><th><strong>Age</strong></th><th><strong>Last donated</strong></th><th><strong>Mobile No</strong></th><th><strong>City</strong></th></tr>
</thead>
<tbody>
    <?php

if(isset($_POST['submit']))
{
$blood=$_POST['blood'];     
    echo "$blood blood records";
    $sql = "SELECT * FROM bloo WHERE blood LIKE '$blood%'  " ;
    $result = $con->query($sql);
    if ($result->num_rows > 0) {
    // output data of each row
$count=1;
while($row = mysqli_fetch_assoc($result)) { ?>
<tr><td align="center"><?php echo $count; ?></td><td align="center"><?php echo $row["uname"]; ?></td><td align="center"><?php echo $row["blood"]; ?></td><td align="center"><?php echo $row["age"]; ?></td><td align="center"><?php echo $row["dd"]; ?></td><td align="center"><?php echo $row["mobile"]; ?></td><td align="center"><?php echo $row["city"]; ?></td></tr>
<?php $count++; }
        
} else {
    echo "0 results";
}
}
$con->close();
?>


    