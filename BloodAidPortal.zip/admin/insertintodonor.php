<?php
require('db.php');
include("auth.php");

$status = "";
if(isset($_POST['new']) && $_POST['new']==1)
{
    $Rname = $_REQUEST['Rname'];
    $blood1=$_REQUEST['blood1'];
    $Dname = $_REQUEST['Dname'];
    $ddate= $_REQUEST['ddate'];
    $Hname = $_REQUEST['Hname'];


$ins_query = "INSERT INTO donations (Rname,blood1,Dname,ddate,Hname) VALUES ('$Rname', '$blood1', '$Dname','$ddate','$Hname')";
mysqli_query($con,$ins_query) or die(mysql_error());
$status = "New Record Inserted Successfully.</br></br>";
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Insert New Record</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<div class="form">
<p><a href="dashboard.php">Dashboard</a> | <a href="logout.php">Logout</a></p>

<div>
<h1>Insert New Record</h1>
<form name="form" method="post" action=""> 
<input type="hidden" name="new" value="1" />
<p><input type="text" name="Rname" placeholder="Requested person Name" required  /></p>
<p><input type="text" name="blood1" placeholder="Enter BLood Group" required  /></p>
<p><input type="text" name="Dname" placeholder="eneter donor name" required  /></p>
<p><input type="date" name="ddate" placeholder="donated date" required  /></p>
<p><input type="text" name="mobile" placeholder="Enter Mobile No" required  /></p>
<p><input type="text" name="Hname" placeholder="Enter Hospital Name" required  /></p>
<p><input name="submit" type="submit" value="insert" /></p>
</form>
<p style="color:#FF0000;"><?php echo $status; ?></p>
</div>
</div>
</body>
</html>
