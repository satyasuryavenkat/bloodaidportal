<?php
session_start();
$_SESSION['number']=$_GET['pho'];

?>

        <h1>Are You Available to Donate Now</h1>
        <form method="POST" action="form.php?pho=<?php echo $_SESSION['number'] ?>">


        <input type="submit" name="action" value="YES" />
        <input type="submit" name="action" value="NO" />
</form>






<form method="POST" action="form.php?pho=<?php echo $_SESSION['number'] ?>" >
<?php 
$con = mysqli_connect("localhost", "id11481374_surya", "Nsurya@123", "id11481374_blood");
$pho=$_SESSION['number'];
$val="";
if($_SERVER['REQUEST_METHOD'] == 'POST'){



    if(!empty($_POST['fname']))
    {
        $p=$_POST['fname'];
        $sp="UPDATE bloo SET dd = $p WHERE mobile = $pho";
        $fun=mysqli_query($con,$sp);
        echo"Updated Successfully Thank You :)$pho";
    }
else if($_POST['action']=='YES')
{
    
    echo"The hospital location you supposed to Donate blood-->(LINK)";
}
else if($_POST['action']=='NO')
{
    
    echo"How Many months ago You Have Donated Blood??(Enter Only Number)<br>";
    echo"<input name='fname' type='text' class='textfield' id='fname' value='$val' />";
    echo "<input type='submit' name='submit' value='Submit'>";
}

}

?>




</form>
