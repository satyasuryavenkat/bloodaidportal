<?php

$con=mysqli_connect("localhost","swecha","swecha","blood");
if(mysqli_connect_errno())
{
	echo "Successfully".mysqli_connect_error();
}

?>