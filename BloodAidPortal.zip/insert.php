<?php
$con = mysqli_connect("localhost", "id11481374_surya", "Nsurya@123", "id11481374_blood");
 

if($con === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
$name = $_POST['name'];
$blood=$_POST['blood'];
$age = $_POST['age'];
$city= $_POST['city'];
$mobile = $_POST['number'];
$ld= $_POST['ago'];


 

$sql = "INSERT INTO bloo (uname,blood,age,mobile,city,dd) VALUES ('$name', '$blood', $age,'$mobile','$city','$ld')";
$result=mysqli_query($con,$sql);

if($result==true)
{
    echo "<h1>Thank You for Being a Blood Donor..You will Receive a Message when there is a Requirement!! </h1>";
    
}



?>