<?php include('init.php')?>

<?php 
$obj = new base_class;


       

if($obj->Normal_Query("SELECT dd,uname,blood,id,mobile from bloo")){

    echo "the donor"

    echo $name;

    echo "of blood group"

    echo $blood;
    
    echo "has donated his blood "

    echo $dd;
    
    echo "months ago and his mobile number is"

    echo $mobile."<br>";


}
					?>
