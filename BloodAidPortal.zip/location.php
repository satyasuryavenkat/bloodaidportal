
<form action='' method='POST'>
     Enter Your Mobile Number <br>
    <input name='num1' type='text' class='textfield' /><br>
        Enter Your New Location (city)<br>
    <input name='new' type='text' class='textfield' />
    <input type='submit' name='submit' value='Submit'>
    </form>

<?php
$con = mysqli_connect("localhost", "id11481374_surya", "Nsurya@123", "id11481374_blood");
    if(isset($_POST['submit'])){

    if(!empty($_POST['num1'])&& !empty($_POST['new']))
    {
        $new=$_POST['new'];
        $num=$_POST['num1'];
        $sp="UPDATE bloo SET mobile = $new WHERE mobile = $num";
        $fun=mysqli_query($con,$sp);
        echo"Updated Successfully Thank You :)";
    }
    else
    {
        echo"please fill details";
    }
    }
?>