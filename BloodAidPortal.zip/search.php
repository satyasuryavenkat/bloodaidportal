<?php include('init.php')?>
<?php 
$obj = new base_class;


$con = mysqli_connect("localhost", "id11481374_surya", "Nsurya@123", "id11481374_blood");

if(isset($_POST['submit']))
{
    $result=$_POST['blod'];
    $number=$_POST['num'];
    
    $addr=$_POST['ad1'];
    $city=$_POST['cit'];
    
    
$lol=" INSERT INTO requests (remobile, rehospital,reblood,recity,status)  values('$number','$addr','$result','$city','STARTED')";

$process=mysqli_query($con,$lol);
if($process==true)
{
    echo"<h1>Your Request Is under Process SMS are sent to all ".$result."  donars in our Database <br> You will Receive SMS who are available to Donate </h1>";
}
if($obj->Normal_Query("SELECT * from bloo where blood LIKE '$result%' ")){

    $blood_result = $obj->fetch_all();


foreach($blood_result as $informations):
    $id = $informations->id;
    $name = $informations->uname;
    $blood=$informations->blood;
    $mobile=$informations->mobile;
    $link=urlencode('https://bloodautoportal.000webhostapp.com/form.php?pho=<?php echo $mobile ?>');

    $new='I need '.$blood.'Blood Urgently. Please Come and Donate at '.$addr.' For more Information Contact '.$number.'Go through this link ';
    $msg=urlencode($new.$link);
    
    $url="https://www.160by2.com/api/v1/sendCampaign";

$curl = curl_init();
curl_setopt($curl, CURLOPT_POST, 1);// set post data to true
curl_setopt($curl, CURLOPT_POSTFIELDS, "apikey=UIII3E6ERJNQMF5KE1IKXF8X6GWIBC95&secret=HE4L68TGD8LZA9N8&usetype=stage&phone=$mobile&senderid=Blood&message=$msg");// post data
// query parameter values must be given without squarebrackets.
 // Optional Authentication:
curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
$result = curl_exec($curl);
curl_close($curl);
echo $result;


    echo $name."        ";

    echo $blood."       ";

    echo $mobile."<br>";

    

    
    

endforeach;
}




}
					?>