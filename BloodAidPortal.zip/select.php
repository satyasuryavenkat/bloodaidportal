<?php include('init.php')?>
<?php 
$obj = new base_class;




    $result=$_GET['type'];
    
if($result=='apos')
{
    $re='A+';
}
else if($result=='aneg')
{
    $re='A-';
}
else if($result=='bpos')
{
    $re='B+';
}
else if($result=='bneg')
{
    $re='B-';
}
else if($result=='abpos')
{
    $re='AB+';
}
else if($result=='abneg')
{
    $re='AB-';
}
else if($result=='opos')
{
    $re='O+';
}
else if($result=='oneg')
{
    $re='O-';
}
   
    
    
   $co=1;



if($obj->Normal_Query("SELECT * from bloo where blood LIKE '$re%' ")){

    $blood_result = $obj->fetch_all();

echo"<center>";
echo "<table>
       <tr>
                <th>S.No</th>
                <th>Name</th>
                 <th>Blood Group</th>
                  <th>Mobile Number</th>
            </tr>";
foreach($blood_result as $informations):
    $id = $informations->id;
    $name = $informations->uname;
    $blood=$informations->blood;
    $mobile=$informations->mobile;
    
    
    
    echo "<tr><td>$co</td><td>$name</td><td>$blood</td><td>$mobile</td></tr>";
    
    $co+=1;
    

endforeach;
}
echo "</table>";
echo"</center>";



					?>