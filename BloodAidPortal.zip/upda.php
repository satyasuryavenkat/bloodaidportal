<?php 
$con = mysqli_connect("localhost", "id11481374_surya", "Nsurya@123", "id11481374_blood");
$ld="";
$cit="";
$num="";

$new="";

$kiki=$_GET['meme'];
 if($kiki=='mb')
{
 echo"<form action='' method='POST'>";
     echo"Enter Your Previous Mobile Number <br>";
    echo"<input name='fname' type='text' class='textfield' id='num1' value='$num' /><br>";
        echo"Enter Your New Mobile Number<br>";
    echo"<input name='fname' type='text' class='textfield' id='new' value='$new' />";
    echo "<input type='submit' name='submit' value='Submit'>";
    echo"</form>";
    if(isset($_POST['submit'])){

    if(!empty($_POST['num1'])&& !empty($_POST['new']))
    {
        $new=$_POST['new'];
        $sp="UPDATE bloo SET mobile = $new WHERE mobile = $num";
        $fun=mysqli_query($con,$sp);
        echo"Updated Successfully Thank You :)";
    }
    else
    {
        echo"please fill details";
    }
   
}
}
 else if($kiki=='adr')
{
    echo"<form action='' method='POST'>";
     echo"Enter Your Mobile Number <br>";
    echo"<input name='fname' type='text' class='textfield' id='num2' value='$num' /><br>";
        echo"Enter Your New Address (City) <br>";
    echo"<input name='fname' type='text' class='textfield' id='cit' value='$cit' />";
    echo "<input type='submit' name='submit' value='Submit'>";
     echo"</form>";
    if(isset($_POST['submit'])){
    
     if(!empty($_POST['num2'])&& !empty($_POST['cit']))
    {
        $cit=$_POST['cit'];
        $sp="UPDATE bloo SET city = $cit WHERE mobile = $num";
        $fun=mysqli_query($con,$sp);
        echo"Updated Successfully Thank You :)";
    }
    else
    {
        echo"Please Enter Details";
    }
     
    
}
}

else if($kiki=='ld')
{
    echo"<form action='' method='POST'>";
    echo"Enter Your Mobile Number<br>";
    echo"<input name='fname' type='text' class='textfield' id='num3' value='$num' /><br>";
    echo"How Many months ago You Have Donated Blood??(Enter Only Number)<br>";
    echo"<input name='fname' type='text' class='textfield' id='ld' value='$ld' />";
    echo "<input type='submit' name='submit' value='Submit'>";
     echo"</form>";
    if(isset($_POST['submit'])){
 if(!empty($_POST['num3'])&& !empty($_POST['ld']))
    {
        $ld=$_POST['ld'];
        $sp="UPDATE bloo SET dd = $ld WHERE mobile = $num";
        $fun=mysqli_query($con,$sp);
        echo"Updated Successfully Thank You :)";
    }
    else
    {
            echo"Please Enter Details";
    }

}
}







?>